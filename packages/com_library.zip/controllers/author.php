<?php
//only include Kcontroller,it includes these functions : ( Koowa 0.6)
/* _getRequest($hash,$mask)
 * access
 * cancel
 * delete
 * edit
 * enable
 * order
 * save
 */ 
class LibraryControllerAuthor extends KControllerPage
{

}