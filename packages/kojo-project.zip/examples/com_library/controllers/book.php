<?php

class LibraryControllerBook extends KControllerPage
{

}