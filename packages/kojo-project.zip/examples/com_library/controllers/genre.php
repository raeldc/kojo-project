<?php

class LibraryControllerGenre extends KControllerPage
{

}