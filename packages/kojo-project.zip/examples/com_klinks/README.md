A Rewrite of **com_weblinks** using the [KoJo Framework](http://github.com/raeldc/kojo-project)
======================================================

For now, this component is just a rewrite of the frontend without the link submission form.

Download the latest installable package [here](http://github.com/raeldc/kojo-project/downloads)
==========================================================================================================