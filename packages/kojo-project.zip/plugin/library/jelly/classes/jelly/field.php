<?php defined('SYSPATH') or die('No direct script access.');

abstract class Jelly_Field extends Jelly_Field_Core
{

}
