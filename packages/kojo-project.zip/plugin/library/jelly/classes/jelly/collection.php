<?php defined('SYSPATH') or die('No direct script access.');

class Jelly_Collection extends Jelly_Collection_Core
{

}
