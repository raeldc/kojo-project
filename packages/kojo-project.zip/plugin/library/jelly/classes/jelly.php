<?php defined('SYSPATH') or die('No direct script access.');

abstract class Jelly extends Jelly_Core
{

}