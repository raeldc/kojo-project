<?php defined('SYSPATH') or die('No direct script access.');

class Field_Enum extends Jelly_Field_Enum
{

}