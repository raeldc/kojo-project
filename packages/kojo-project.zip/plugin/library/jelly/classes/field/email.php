<?php defined('SYSPATH') or die('No direct script access.');

class Field_Email extends Jelly_Field_Email
{

}