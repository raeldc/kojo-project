<?php defined('SYSPATH') or die('No direct script access.');

class Field_Slug extends Jelly_Field_Slug
{

}