<?php defined('SYSPATH') or die('No direct script access.');

class Field_Expression extends Jelly_Field_Expression
{

}