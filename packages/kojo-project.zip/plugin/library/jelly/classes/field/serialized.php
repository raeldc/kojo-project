<?php defined('SYSPATH') or die('No direct script access.');

class Field_Serialized extends Jelly_Field_Serialized
{

}