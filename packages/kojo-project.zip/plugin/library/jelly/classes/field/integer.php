<?php defined('SYSPATH') or die('No direct script access.');

class Field_Integer extends Jelly_Field_Integer
{

}