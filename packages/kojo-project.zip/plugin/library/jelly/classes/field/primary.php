<?php defined('SYSPATH') or die('No direct script access.');

class Field_Primary extends Jelly_Field_Primary
{

}