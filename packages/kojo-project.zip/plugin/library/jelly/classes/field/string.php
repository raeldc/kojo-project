<?php defined('SYSPATH') or die('No direct script access.');

class Field_String extends Jelly_Field_String
{

}