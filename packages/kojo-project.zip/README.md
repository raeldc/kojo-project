This is just a crazy idea
=========================

I'm a Joomla developer first and foremost, but I also fell inlove with Kohana 3. I love Kohana's clean and consistent framework.
How I wish Joomla was written in such a beautiful and easy way!

Kohana was written in such a way that it gets out of the way of developers. It's so flexible, and also very light, it can actually 
run inside Joomla. With some hacks here and there, I think I'll be able to make Kohana work flawlessly inside Joomla.

Once I achieve that goal, then I can enjoy the best of both worlds!

I was also checking Nooku, a framework for Joomla written by former Joomla 1.5 lead developer Johan Janssens. Unfortunately, I am
not impressed. So if I can make this integration work, I bet Kooja will be a tough competition to Nooku. 

I haven't considered all the repercussions of integrating Kohana into Joomla, but I'm crossing my fingers. I hope I can make this work.

Send me a message if you want to join this project!