<?php defined('SYSPATH') or die('No direct script access.');

class Field_Password extends Jelly_Field_Password
{

}