<?php defined('SYSPATH') or die('No direct script access.');

class Field_Float extends Jelly_Field_Float
{

}