<?php defined('SYSPATH') or die('No direct script access.');

class View_Layout extends Kostache {

	/**
	 * @var string template title
	 */
	public $title = 'Brought to you by KOstache!';

	/**
	 * @var string template content
	 */
	public $content = 'Hello, world!';

} // End View_Template