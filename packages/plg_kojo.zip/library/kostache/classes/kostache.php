<?php
class Kostache extends Kohana_Kostache {}