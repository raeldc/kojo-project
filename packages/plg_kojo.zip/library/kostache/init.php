<?php

include Kohana::find_file('vendor', 'mustache/Mustache');
