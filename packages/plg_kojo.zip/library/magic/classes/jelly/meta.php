<?php defined('SYSPATH') or die('No direct script access.');

class Jelly_Meta extends Magic_Jelly_Meta{}