<?php defined('SYSPATH') or die('No direct script access.');

class Jelly_Model extends Magic_Jelly_Model{}