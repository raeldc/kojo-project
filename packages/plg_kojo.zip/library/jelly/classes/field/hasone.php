<?php defined('SYSPATH') or die('No direct script access.');

class Field_HasOne extends Jelly_Field_HasOne
{

}