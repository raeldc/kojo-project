<?php defined('SYSPATH') or die('No direct script access.');

class Field_Timestamp extends Jelly_Field_Timestamp
{

}