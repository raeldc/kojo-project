<?php defined('SYSPATH') or die('No direct script access.');

class Field_BelongsTo extends Jelly_Field_BelongsTo
{

}