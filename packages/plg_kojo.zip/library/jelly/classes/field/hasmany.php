<?php defined('SYSPATH') or die('No direct script access.');

class Field_HasMany extends Jelly_Field_HasMany
{

}