<?php defined('SYSPATH') or die('No direct script access.');

class Field_Text extends Jelly_Field_Text
{

}