<?php
	foreach ($categories as $category) 
	{
		echo Kohana::debug($category->title);
	}
?>