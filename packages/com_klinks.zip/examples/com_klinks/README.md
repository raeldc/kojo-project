A Rewrite of **com_weblinks** using the KoJo Framework
======================================================

KoJo Allows you to write Joomla Extensions using the light and swift framework, Kohana 3.

For now, this component is just a rewrite of the frontend without the link submission form.